package unidad3;


public class Ejercicio01 {
    
    public static String calificar(int nota) {
        return null;
    }
}

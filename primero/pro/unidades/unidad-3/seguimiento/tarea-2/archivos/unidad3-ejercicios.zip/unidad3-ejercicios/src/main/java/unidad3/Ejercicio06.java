package unidad3;


public class Ejercicio06 {

    public static long factorial(int n) {
        return 0;
    }
}

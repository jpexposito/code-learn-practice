package unidad3;



public class Ejercicio02 {

    
    public static double operar(double a, double b, int opcion) {
        return 0;
    }
}

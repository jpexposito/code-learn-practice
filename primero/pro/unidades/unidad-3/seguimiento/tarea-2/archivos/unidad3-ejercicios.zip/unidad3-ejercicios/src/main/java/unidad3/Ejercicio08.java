package unidad3;

public class Ejercicio08 {

    public static boolean esPrimo(int n) {

        return false;
    }
}

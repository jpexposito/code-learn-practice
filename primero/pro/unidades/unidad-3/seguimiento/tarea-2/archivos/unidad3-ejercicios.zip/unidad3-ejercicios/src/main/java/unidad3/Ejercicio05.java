package unidad3;


public class Ejercicio05 {

    public static int[] tablaMultiplicar(int n) {
        return null;
    }

    
    public static int sumaTabla(int n) {
        return 0;
    }
}

package com.docencia.personas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonasApplication {

    public static void main(String[] args) {
        SpringApplication.run(PersonasApplication.class, args);
    }
}

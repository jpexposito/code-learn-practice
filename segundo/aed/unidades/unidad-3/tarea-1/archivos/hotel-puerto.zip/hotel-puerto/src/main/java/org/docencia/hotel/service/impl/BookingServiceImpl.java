package org.docencia.hotel.service.impl;

import org.docencia.hotel.service.api.BookingService;
import org.springframework.stereotype.Service;

@Service
public class BookingServiceImpl implements BookingService {
    // TODO: inyectar repositorios + mappers y aplicar lógica
}

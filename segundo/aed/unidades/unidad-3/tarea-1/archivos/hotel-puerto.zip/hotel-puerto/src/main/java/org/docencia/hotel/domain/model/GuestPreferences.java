package org.docencia.hotel.domain.model;

public class GuestPreferences {
    // TODO: modelo de dominio (sin anotaciones de persistencia)
}

package org.docencia.hotel.domain.impl;

import org.docencia.hotel.domain.api.GuestDomain;
import org.docencia.hotel.service.api.GuestService;
import org.springframework.stereotype.Service;

@Service
public class GuestDomainImpl implements GuestDomain {

    private final GuestService service;

    public GuestDomainImpl(GuestService service) {
        this.service = service;
    }

    // TODO
}

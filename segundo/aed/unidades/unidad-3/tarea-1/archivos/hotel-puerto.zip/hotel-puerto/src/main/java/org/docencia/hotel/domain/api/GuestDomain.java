package org.docencia.hotel.domain.api;

public interface GuestDomain {
    // TODO
}

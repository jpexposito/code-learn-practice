package org.docencia.hotel.domain.model;

public class Room {
    // TODO: modelo de dominio (sin anotaciones de persistencia)
}

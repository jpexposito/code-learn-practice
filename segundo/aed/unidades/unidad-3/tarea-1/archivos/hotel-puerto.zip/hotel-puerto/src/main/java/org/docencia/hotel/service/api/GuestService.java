package org.docencia.hotel.service.api;

public interface GuestService {
    // TODO
}

package org.docencia.hotel.persistence.repository.jpa;

public interface RoomRepository {
    // TODO: contrato JPA
}

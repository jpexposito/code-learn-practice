package org.docencia.hotel.persistence.repository.nosql;

public interface GuestPreferencesRepository {
    // TODO: contrato NoSQL
}

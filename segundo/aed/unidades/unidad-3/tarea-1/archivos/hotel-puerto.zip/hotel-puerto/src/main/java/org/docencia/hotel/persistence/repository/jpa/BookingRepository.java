package org.docencia.hotel.persistence.repository.jpa;

public interface BookingRepository {
    // TODO: contrato JPA
}

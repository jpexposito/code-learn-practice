package org.docencia.hotel.persistence.repository.jpa;

public interface GuestJpaRepository {
    // TODO: contrato JPA
}

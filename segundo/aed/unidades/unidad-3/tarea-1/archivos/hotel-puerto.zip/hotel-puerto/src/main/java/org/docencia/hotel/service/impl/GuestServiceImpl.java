package org.docencia.hotel.service.impl;

import org.docencia.hotel.service.api.GuestService;
import org.springframework.stereotype.Service;

@Service
public class GuestServiceImpl implements GuestService {
    // TODO: inyectar repositorios + mappers y aplicar lógica
}

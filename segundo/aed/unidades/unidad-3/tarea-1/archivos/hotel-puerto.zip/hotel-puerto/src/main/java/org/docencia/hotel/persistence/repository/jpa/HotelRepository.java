package org.docencia.hotel.persistence.repository.jpa;

public interface HotelRepository {
    // TODO: contrato JPA
}

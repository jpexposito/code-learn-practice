package org.docencia.hotel.domain.model;

public class Booking {
    // TODO: modelo de dominio (sin anotaciones de persistencia)
}

package org.docencia.hotel;

import org.junit.jupiter.api.Test;


class EjemploTest {

    @Test
    void ejemploTest1() {
        
    }
}

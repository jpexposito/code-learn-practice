package org.docencia.hotel.domain.api;

public interface HotelDomain {
    // TODO
}

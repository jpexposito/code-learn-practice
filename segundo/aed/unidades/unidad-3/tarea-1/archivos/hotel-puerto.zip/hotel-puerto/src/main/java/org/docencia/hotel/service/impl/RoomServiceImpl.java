package org.docencia.hotel.service.impl;

import org.docencia.hotel.service.api.RoomService;
import org.springframework.stereotype.Service;

@Service
public class RoomServiceImpl implements RoomService {
    // TODO: inyectar repositorios + mappers y aplicar lógica
}

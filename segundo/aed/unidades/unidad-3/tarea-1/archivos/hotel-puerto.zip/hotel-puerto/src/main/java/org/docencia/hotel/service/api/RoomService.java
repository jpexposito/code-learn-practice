package org.docencia.hotel.service.api;

public interface RoomService {
    // TODO
}

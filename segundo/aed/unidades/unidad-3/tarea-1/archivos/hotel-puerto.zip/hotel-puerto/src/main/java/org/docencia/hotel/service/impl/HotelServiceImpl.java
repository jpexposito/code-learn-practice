package org.docencia.hotel.service.impl;

import org.docencia.hotel.service.api.HotelService;
import org.springframework.stereotype.Service;

@Service
public class HotelServiceImpl implements HotelService {
    // TODO: inyectar repositorios + mappers y aplicar lógica
}

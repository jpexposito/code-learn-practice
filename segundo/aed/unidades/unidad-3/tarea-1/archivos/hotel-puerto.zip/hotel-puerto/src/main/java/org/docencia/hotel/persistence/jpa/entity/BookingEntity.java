package org.docencia.hotel.persistence.jpa.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "booking")
public class BookingEntity {
    // TODO: @Id + campos + relaciones
}

package com.docencia.objetos.domain;

// TODO: añadir validación (jakarta.validation) si se desea
public class Alumno {
  // TODO: definir campos y encapsulación
  private Long id;
  private String nombre;
  private String email;
  private String ciclo;

  // TODO: constructores, getters y setters
}

package com.docencia.objetos.repo.jpa;

// TODO: añadir @Entity, @Table, @Id, @GeneratedValue, etc.
public class AlumnoEntity {
  // TODO: definir campos y mapeos
  private Long id;
  private String nombre;
  private String email;
  private String ciclo;

  // TODO: getters/setters
}
